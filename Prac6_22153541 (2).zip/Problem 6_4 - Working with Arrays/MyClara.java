/* PERMITTED COMMANDS 
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront,
   addTree(x, y),
   JAVA
   if, while, for, do, &&, !, ||, variables, arrays
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' function you can write your program for Clara 
     */
    void run() {
    }
}