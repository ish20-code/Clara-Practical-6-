/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below

    // Create a cake that is 18 cells wide and 4 cells high
    for (int a = 1; a < 3; a++) {
        putLeaf();
        for (int u = 2; u <= 18; u++) {
            moveLeaf();
        }
        turnLeft();
        moveLeaf();
        turnLeft();

        for (int c = 2; c <= 18; c++) {
            moveLeaf();
        }
        turnRight();
        move();
        turnRight();
    }

    // Prompt the user for an age input
    int age = readInt("Age");

    // Re-prompt if the entered age is outside the valid range
    while (age < 9 || age > 100) {
        age = readInt("Please use a number between 10 and 99");
    }

    // Find the middle of the cake and determine candle placement
    if (age < 100) {
        int candlesCells = age - age / 10 * 10;
        if (candlesCells == 0) {
            candlesCells++;
        }

        // Move to the starting position to place the first candle
        for (int r = 1; r <= (9 - age / 10) + 1; r++) {
            move();
        }

        // Place candles on the cake
        for (int can = 1; can <= age / 10; can++) {
            turnLeft();
            for (int Cel = 1; Cel <= candlesCells; Cel++) {
                putLeaf();
                move();
            }
            turnLeft();
            turnLeft();

            // Move to the next candle position
            for (int Ce = 1; Ce <= candlesCells; Ce++) {
                move();
            }
            turnLeft();
            move();
            move();
        }
    }
}

// Helper function to move and place a leaf
void moveLeaf() {
    move();
    putLeaf();
}
}

