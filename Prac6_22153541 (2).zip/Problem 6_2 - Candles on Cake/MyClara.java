/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
    // Clara asks for the width (number of cells) for the cake
    int cell = readInt("Enter the width in cells:");
    // If the user provides a number greater than 18, Clara asks again
    while (cell > 18) {
        cell = readInt("Please enter a number less than or equal to 18:");
    }
    // Clara asks for the height of the cake
    double height = readInt("Enter the height:");
    // If the user provides a number greater than 13, Clara asks again
    while (height > 13) {
        height = readInt("Please enter a number less than or equal to 13:");
    }

    /*
     * Clara builds the cake with the specified width and height.
     * Clara places candles with one empty cell between each.
     */

    if (cell <= 18 && height <= 13) {
        int d = 0;
        // Clara places leaves and moves from left to right
        while (height > d) {
            putLeaf();
            for (int u = 2; u <= cell; u++) {
                moveLeaf();
            }
            turnLeft();
            move();
            turnLeft();
            height--;
            // Clara places leaves and moves from right to left
            if (d < height) {
                putLeaf();
                for (int c = 2; c <= cell; c++) {
                    moveLeaf();
                }
                RMoveR();
                height--;
            }
        }
    }
    // Clara turns and checks if she is on the right or left side of the board
    turnRight();
    move();
    // Clara places candles from left to right
    if (!onLeaf()) {
        turnLeft();
        turnLeft();
        move();
        turnRight();
        for (int t = 1; t <= cell / 2; t++) {
            turnRight();
            place();
            turnRight();
            turnMoveR();
            turnMoveR();
        }
    }
    // Clara places candles from right to left
    else {
        turnRight();
        RMoveR();
        for (int t = 1; t <= cell / 2; t++) {
            turnLeft();
            place();
            turnLeft();
            turnMoveL();
            turnMoveL();
        }
    }
}

// Clara turns right and moves two cells
void turnMoveR() {
    turnRight();
    move();
    move();
}

// Clara moves forward and places a leaf
void moveLeaf() {
    move();
    putLeaf();
}

// Clara turns left and moves two cells
void turnMoveL() {
    turnLeft();
    move();
    move();
}

// Clara places a leaf, moves, and places another leaf twice
void place() {
    putLeaf();
    moveLeaf();
    moveLeaf();
}

// Clara turns right, moves, then turns right again
void RMoveR() {
    turnRight();
    move();
    turnRight();
}
}



