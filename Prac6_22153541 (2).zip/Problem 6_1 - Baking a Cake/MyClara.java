/* PERMITTED COMMANDS
   move, turnLeft, turnRight, treeLeft, treeRight, treeFront, onLeaf, putLeaf, removeLeaf, mushroomFront
   JAVA
   if, while, for
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
int width = readInt("Width (Max 18)");

// Repeat until the user inputs a valid width
while (width > 18) {
    width = readInt("Please enter a width of 18 or less");
}

int height = readInt("Height (Max 13)");

// Repeat until the user inputs the right height
while (height > 13) {
    height = readInt("Please enter a height of 13 or less");
}

// Clara builds the cake with the plausible width and height
for (int currentHeight = 0; currentHeight < height; currentHeight++) {
    // Build a row from left to right
    for (int i = 0; i < width; i++) {
        putLeaf();
        if (i < width - 1) {
            move();
        }
    }
    
    // Move down and switch direction
    if (currentHeight < height - 1) {
        turnLeft();
        move();
        turnLeft();

        currentHeight++;

        // Build a row from right to left
        for (int i = 0; i < width; i++) {
            putLeaf();
            if (i < width - 1) {
                move();
            }
        }
        
        // Move down and switch direction
        if (currentHeight < height - 1) {
            turnRight();
            move();
            turnRight();
        }
    }
}
}
}
